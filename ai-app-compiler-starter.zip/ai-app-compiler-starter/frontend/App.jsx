
export default function App() {
  return (
    <div>
      <h1>AI App Compiler</h1>
      <textarea placeholder="Describe your app idea..." />
      <button>Generate</button>
    </div>
  );
}
