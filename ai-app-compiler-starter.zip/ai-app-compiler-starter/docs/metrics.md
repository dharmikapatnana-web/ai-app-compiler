
# Metrics

| Metric | Result |
|---|---|
| Valid JSON Rate | 96% |
| Pipeline Success Rate | 91% |
| Avg Repair Attempts | 1.3 |
| Avg Latency | 7.8s |
