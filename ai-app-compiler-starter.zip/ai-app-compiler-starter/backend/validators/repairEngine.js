
export async function repairSchemas(errors, schemas) {
  console.log("Repairing:", errors);

  if (errors.includes("Missing contacts table")) {
    schemas.db.tables.push("contacts");
  }

  return schemas;
}
