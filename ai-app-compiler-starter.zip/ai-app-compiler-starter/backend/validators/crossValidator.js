
export function validateSchemas(schemas) {
  const errors = [];

  if (!schemas.db.tables.includes("contacts")) {
    errors.push("Missing contacts table");
  }

  return {
    valid: errors.length === 0,
    errors
  };
}
