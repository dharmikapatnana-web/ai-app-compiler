
export async function generateSchemas(design) {
  return {
    ui: {
      pages: ["dashboard", "contacts"]
    },
    api: {
      endpoints: ["/contacts"]
    },
    db: {
      tables: ["users", "contacts"]
    }
  };
}
