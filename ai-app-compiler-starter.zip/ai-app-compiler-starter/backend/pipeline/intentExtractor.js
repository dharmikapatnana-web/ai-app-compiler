
export async function extractIntent(prompt) {
  return {
    app_type: "CRM",
    features: ["auth", "dashboard", "payments"],
    roles: ["admin", "user"]
  };
}
