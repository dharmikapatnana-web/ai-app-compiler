
export async function designSystem(intent) {
  return {
    entities: ["User", "Contact", "Subscription"],
    flows: ["login", "create_contact"],
    roles: intent.roles
  };
}
