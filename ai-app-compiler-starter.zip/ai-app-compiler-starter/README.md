
# AI App Compiler Starter

A compiler-style AI system that converts natural language into executable app configurations.

## Pipeline

User Prompt
→ Intent Extraction
→ System Design
→ Schema Generation
→ Validation
→ Repair Engine
→ Runtime Execution

## Tech Stack
- Node.js
- Express
- OpenAI API
- Zod
- Prisma
- React + Vite

## Folder Structure

/backend
/frontend
/runtime
/docs

## Features
- Multi-stage pipeline
- Strict schema validation
- Repair engine
- Runtime-aware generation
- Deterministic JSON outputs
